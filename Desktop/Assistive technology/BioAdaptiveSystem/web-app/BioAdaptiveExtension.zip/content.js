// Bio-Adaptive Content Script
// 1. Listens for PostMessage from the main web application (if on the dashboard page)
// 2. Receives broadcasted scores from background script and applies CSS/DOM changes

// --- PART 1: Broadcast interception (for the Web App tab) ---
window.addEventListener('message', (event) => {
    // Only accept messages with the proper type
    if (event.data && event.data.type === 'BIO_ADAPTIVE_STATE') {
        // Send ACK back to the web app
        window.postMessage({ type: 'BIO_ADAPTIVE_ACK', timestamp: Date.now() }, '*');

        // Verify extension context is still valid before sending
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
            try {
                chrome.runtime.sendMessage({
                    type: 'UPDATE_FATIGUE_SCORE',
                    score: event.data.fatigueScore
                }).catch(() => { }); // Silence unhandled promise rejections
            } catch (err) { }
        }
    } else if (event.data && event.data.type === 'BIO_ADAPTIVE_PRIVACY_TOGGLE') {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
            try {
                chrome.runtime.sendMessage({
                    type: 'TOGGLE_PRIVACY_MODE',
                    privacyMode: event.data.privacyMode
                }).catch(() => { });
            } catch (err) { }
        }
    }
});

// --- PART 2: Adaptation Engine (for ALL tabs) ---
// Listen for updates from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'APPLY_FATIGUE_ADAPTATION') {
        applyAdaptations(message.state);
        sendResponse({ success: true });
    }
    if (message.type === 'SHOW_BREAK_BANNER') {
        showBreakBanner();
    }
});

// Initialize on load
chrome.runtime.sendMessage({ type: 'GET_CURRENT_STATE' }, (res) => {
    if (res && res.state) {
        applyAdaptations(res.state);
    }
});
chrome.storage.local.get(['privacyMode'], (result) => {
    if (result.privacyMode) startBehavioralTracking();
});

// The Adaptation Logic
let breakBannerEl = null;

function applyAdaptations(state) {
    const html = document.documentElement;
    if (!html.classList.contains('bio-adaptive-initialized')) {
        html.classList.add('bio-adaptive-initialized');
    }

    // Remove all classes first to reset state cleanly
    html.classList.remove(
        'bio-adaptive-medium-font',
        'bio-adaptive-large-font',
        'bio-adaptive-reduced-motion',
        'bio-adaptive-focus-mode',
        'bio-adaptive-strict-focus'
    );
    removeBreakBanner();

    if (state === 'LOW_FATIGUE') {
        // Do nothing
    } else if (state === 'MEDIUM_FATIGUE') {
        html.classList.add('bio-adaptive-medium-font', 'bio-adaptive-reduced-motion');
    } else if (state === 'HIGH_FATIGUE') {
        html.classList.add('bio-adaptive-large-font', 'bio-adaptive-reduced-motion', 'bio-adaptive-focus-mode');
    } else if (state === 'CRITICAL_FATIGUE') {
        html.classList.add('bio-adaptive-large-font', 'bio-adaptive-reduced-motion', 'bio-adaptive-strict-focus');
    }
}

// Inject the generic CSS rules if they don't exist
function injectStyles() {
    if (document.getElementById('bio-adaptive-styles')) return;

    const style = document.createElement('style');
    style.id = 'bio-adaptive-styles';
    style.textContent = `
        /* Smooth transitions for adaptations */
        html {
            transition: filter 0.5s ease-in-out, font-size 0.5s ease-in-out !important;
        }

        /* Medium Font & Slight Dimming */
        html.bio-adaptive-medium-font {
            font-size: 105% !important;
            filter: brightness(0.9) sepia(0.1) !important;
        }

        /* Large Font Adaptation */
        html.bio-adaptive-large-font {
            font-size: 110% !important;
        }
        
        html.bio-adaptive-large-font p, 
        html.bio-adaptive-large-font article,
        html.bio-adaptive-large-font section,
        html.bio-adaptive-medium-font p {
            line-height: 1.7 !important;
            letter-spacing: 0.02em !important;
        }

        /* Focus Mode - HIGH FATIGUE */
        html.bio-adaptive-focus-mode {
            filter: brightness(0.8) sepia(0.2) contrast(0.95) !important;
        }

        html.bio-adaptive-focus-mode iframe,
        html.bio-adaptive-focus-mode aside,
        html.bio-adaptive-focus-mode .sidebar,
        html.bio-adaptive-focus-mode [class*="advert"],
        html.bio-adaptive-focus-mode [class*="banner"],
        html.bio-adaptive-focus-mode [class*="social"],
        html.bio-adaptive-focus-mode [id*="ad-"] {
            opacity: 0.2 !important;
            pointer-events: none !important;
            transition: opacity 0.5s ease-in-out !important;
        }

        /* Strict Focus Mode - CRITICAL FATIGUE */
        html.bio-adaptive-strict-focus {
            filter: brightness(0.7) sepia(0.3) contrast(0.95) !important;
        }

        html.bio-adaptive-strict-focus iframe,
        html.bio-adaptive-strict-focus aside,
        html.bio-adaptive-strict-focus .sidebar,
        html.bio-adaptive-strict-focus [class*="advert"],
        html.bio-adaptive-strict-focus [class*="banner"],
        html.bio-adaptive-strict-focus [class*="social"],
        html.bio-adaptive-strict-focus [id*="ad-"] {
            opacity: 0.05 !important;
            pointer-events: none !important;
            transition: opacity 0.5s ease-in-out !important;
        }

        /* Reduced Motion */
        html.bio-adaptive-reduced-motion *,
        html.bio-adaptive-reduced-motion *::before,
        html.bio-adaptive-reduced-motion *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
            scroll-behavior: auto !important;
        }
        
        /* Break Banner - Modern UI */
        #bio-adaptive-break-banner {
            position: fixed;
            top: 20px; 
            left: 50%;
            transform: translateX(-50%);
            width: auto;
            max-width: 400px;
            background: rgba(255, 59, 48, 0.9);
            color: #ffffff;
            text-align: center;
            padding: 16px 24px;
            border-radius: 12px;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            font-size: 16px;
            font-weight: 600;
            z-index: 2147483647; 
            box-shadow: 0 8px 32px rgba(255, 59, 48, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255,255,255,0.2);
            animation: slideDown 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        @keyframes slideDown {
            from { top: -100px; opacity: 0; }
            to { top: 20px; opacity: 1; }
        }
    `;
    document.documentElement.appendChild(style);
}

function showBreakBanner() {
    if (document.getElementById('bio-adaptive-break-banner')) return;

    // Add banner
    breakBannerEl = document.createElement('div');
    breakBannerEl.id = 'bio-adaptive-break-banner';
    breakBannerEl.innerHTML = `⚠️ High Cognitive Fatigue Detected(${Date.now() % 1000} ms).Time for a short break to rest your eyes!`;
    document.body.appendChild(breakBannerEl);

    // Add screen tint
    const overlay = document.createElement('div');
    overlay.id = 'bio-adaptive-overlay';
    document.body.appendChild(overlay);
}

function removeBreakBanner() {
    const banner = document.getElementById('bio-adaptive-break-banner');
    if (banner) banner.remove();

    const overlay = document.getElementById('bio-adaptive-overlay');
    if (overlay) overlay.remove();
}

// --- PART 3: Behavioral Tracking (Privacy Mode) ---
let lastScrollTime = Date.now();
let lastTypeTime = Date.now();
let behavioralTimer = null;

function startBehavioralTracking() {
    window.addEventListener('scroll', () => lastScrollTime = Date.now(), { passive: true });
    window.addEventListener('keydown', () => lastTypeTime = Date.now(), { passive: true });

    if (!behavioralTimer) {
        behavioralTimer = setInterval(analyzeBehavior, 5000);
    }
}

function analyzeBehavior() {
    chrome.storage.local.get(['privacyMode', 'fatigueScore'], (res) => {
        if (!res.privacyMode) {
            clearInterval(behavioralTimer);
            behavioralTimer = null;
            return;
        }

        const now = Date.now();
        const timeSinceScroll = now - lastScrollTime;
        const timeSinceType = now - lastTypeTime;

        let score = res.fatigueScore || 0;

        // Very basic heuristic: if user is on the page but hasn't scrolled or typed in 60 seconds -> staring/fatigue
        if (timeSinceScroll > 60000 && timeSinceType > 60000) {
            score = Math.min(100, score + 10);
        } else if (timeSinceScroll < 5000 || timeSinceType < 5000) {
            // Active interaction reduces fatigue slightly
            score = Math.max(0, score - 5);
        }

        chrome.runtime.sendMessage({
            type: 'UPDATE_FATIGUE_SCORE',
            score: score
        });
    });
}

// User Override Detection: Detect Cmd/Ctrl + '+/-' or Wheel Zoom
window.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        if (e.key === '=' || e.key === '+' || e.key === '-' || e.key === '0') {
            chrome.runtime.sendMessage({ type: 'USER_OVERRIDE' });
        }
    }
});

window.addEventListener('wheel', (e) => {
    if (e.ctrlKey || e.metaKey) {
        chrome.runtime.sendMessage({ type: 'USER_OVERRIDE' });
    }
}, { passive: true });

// Automatically inject styles on startup
injectStyles();
