let currentState = 'LOW_FATIGUE';
let stateLockUntil = 0;
let userOverrideUntil = 0;
let lastBreakTime = 0;

let potentialState = 'LOW_FATIGUE';
let potentialStateStart = 0;
let highFatigueStart = 0;

let creatingOffscreen;
async function playAudioOffscreen() {
    try {
        const hasDoc = await chrome.offscreen.hasDocument();
        if (!hasDoc) {
            if (creatingOffscreen) {
                await creatingOffscreen;
            } else {
                creatingOffscreen = chrome.offscreen.createDocument({
                    url: 'offscreen.html',
                    reasons: ['AUDIO_PLAYBACK'],
                    justification: 'Play critical fatigue warning beep'
                });
                await creatingOffscreen;
                creatingOffscreen = null;
            }
        }
        chrome.runtime.sendMessage({ type: 'PLAY_BEEP' }).catch(() => { });
    } catch (e) { console.error("Offscreen audio failed", e); }
}

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ fatigueScore: 0, privacyMode: false, activeState: 'LOW_FATIGUE' });
});

function getTargetState(score) {
    if (score <= 25) return 'LOW_FATIGUE';
    if (score <= 50) return 'MEDIUM_FATIGUE';
    if (score <= 75) return 'HIGH_FATIGUE';
    return 'CRITICAL_FATIGUE';
}

function processScore(score) {
    const now = Date.now();
    const targetState = getTargetState(score);



    // 3-second confirmation logic
    if (targetState !== potentialState) {
        potentialState = targetState;
        potentialStateStart = now;
    } else if (targetState !== currentState && (now - potentialStateStart) >= 3000) {
        // We've held the new state for 3s continuously

        // Check 3-second stability lock and user override lock
        if (now > stateLockUntil && now > userOverrideUntil) {
            currentState = targetState;
            stateLockUntil = now + 3000; // 3 seconds lock
            chrome.storage.local.set({ activeState: currentState });

            broadcastStateChange();

            // Trigger notification immediately on changing to a dangerous state
            if (currentState === 'HIGH_FATIGUE' || currentState === 'CRITICAL_FATIGUE') {
                if (now - lastBreakTime >= (60 * 1000)) {
                    lastBreakTime = now;
                    broadcastBreak();
                }
            }
        }
    }

    // CONTINUOUS CHECK: Regardless of whether the state just changed or not, 
    // if the user is currently IN a dangerous state, trigger the break notification periodically.
    if ((currentState === 'HIGH_FATIGUE' || currentState === 'CRITICAL_FATIGUE')
        && now > userOverrideUntil
        && now - lastBreakTime >= (60 * 1000)) {

        lastBreakTime = now;
        broadcastBreak();
    }
}

function broadcastStateChange() {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
                type: 'APPLY_FATIGUE_ADAPTATION',
                state: currentState
            }).catch(() => { });
        });
    });
}

function broadcastBreak() {
    playAudioOffscreen();

    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', // transparent 1x1 image
        title: '⚠️ CRITICAL FATIGUE DETECTED',
        message: 'Your focus level has dropped significantly. Please take a short break to rest your eyes!',
        priority: 2,
        requireInteraction: true
    });

    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, { type: 'SHOW_BREAK_BANNER' }).catch(() => { });
        });
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'UPDATE_FATIGUE_SCORE') {
        const score = message.score;
        chrome.storage.local.set({ fatigueScore: score });
        processScore(score);
        sendResponse({ success: true, activeState: currentState });
    }

    if (message.type === 'USER_OVERRIDE') {
        userOverrideUntil = Date.now() + 3000; // 3 seconds for testing
        currentState = 'LOW_FATIGUE';
        chrome.storage.local.set({ activeState: currentState });
        broadcastStateChange();
    }

    if (message.type === 'TOGGLE_PRIVACY_MODE') {
        chrome.storage.local.set({ privacyMode: message.privacyMode });
    }

    if (message.type === 'GET_CURRENT_STATE') {
        sendResponse({ state: currentState });
    }
});
